# Use private endpoints to integrate Azure Functions with a virtual network

## Features

This code is deployed in the tutorial which shows you how to use Azure Functions to connect to resources in an Azure virtual network with private endpoints. You'll create a function with a storage account locked behind a virtual network that uses a service bus queue trigger.

Tutorial: https://docs.microsoft.com/en-us/azure/azure-functions/functions-create-vnet
